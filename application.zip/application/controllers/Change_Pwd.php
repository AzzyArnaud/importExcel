<?php

 class Change_Pwd extends CI_Controller {

    public function __construct() {
        parent::__construct();

    }



     function index() 
     {
   
        $data['msg']="";
        $data['title']="Changer pwd";
        $this->load->view('Change_Pwd_View',$data);

     }

    function changer()
        {

    $this->form_validation->set_rules('ACTUEL_PASSWORD','','trim|required',array('required'=>'Le mot de passe actuel est obligatoire'));
    $this->form_validation->set_rules('NEW_PASSWORD','','trim|required',array('required'=>'Le nouveau mot de passe est obligatoire'));
    $this->form_validation->set_rules('PASSWORDCONFIRM','','trim|required|matches[NEW_PASSWORD]',array('required'=>'La confirmation du nouveau mot de passe est obligatoire','matches'=>'Les deux mot de passe doivent etre identique'));

    
       if($this->form_validation->run()==TRUE)
           {
            

            

            $oldpas=$this->Model->getOne('config_user',array('USERNAME'=>$this->session->userdata('STRAPH_USERNAME')));


            if($oldpas['PASSWORD']==md5($this->input->post('ACTUEL_PASSWORD')))
               {
              $data=array(
               'PASSWORD'=>md5($this->input->post('NEW_PASSWORD')),
               'ENVOIE'=>0
              );

              print_r($data);
              // exit();

              $this->Model->update('config_user',array('USERNAME'=>$this->session->userdata('STRAPH_USERNAME')),$data);

              $data['message']='<div class="alert alert-success text-center">Changement de mot de passe fait avec succès! vous pouvez vous connecter</div>';
              $this->session->set_flashdata($data);
              redirect(base_url('Login/do_logout'));
              }
              else{
                $data['title']="Changer pwd";
                $data['msg']="L'ancien mot de passe n'est pas correct";
                $this->load->view('Change_Pwd_View',$data);
              }
            }

        else{
        $data['msg']="";
        $data['title']="Changer pwd";
        $this->load->view('Change_Pwd_View',$data);
            }
        }
 }