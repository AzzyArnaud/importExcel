<?php 

$config['unites'] = array('1' => 'Unite', '2'=>'carton','3'=>'Fut');
$config['contact_tels'] = array('1' => '+257 22 00 00 00', '2'=>'+257 31 00 00 00');
$config['contact_email'] = array('1' => 'info@pearlhotel.bi', '2'=>'reservation@pearlhotel.bi');
$config['contact_localisation'] = array('1' => '8, Avenue du 13 Octobre, Rohero', '2'=>'Avenue de La Plage, Bujumbura');
?>